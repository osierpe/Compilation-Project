#include "symbol_table.h"
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<ctype.h>

extern table_element *symtab;

void insert_el(char* nome, char* tipo, char* escopo){
	table_element *newSymbol=(table_element*) malloc(sizeof(table_element));
	newSymbol->name = strdup(nome);
	newSymbol->type = strdup(tipo);
	newSymbol->next=NULL;
	newSymbol->prev=NULL;	
	newSymbol->scope = strdup(escopo);
	if(symtab){
		newSymbol->next=symtab;
		symtab->prev=newSymbol;
		symtab=newSymbol;
	}
	else
		symtab=newSymbol;
}  
void search_el(char *str){
	table_element *aux;
	for(aux=symtab; aux; aux=aux->next)
		if(strcmp(aux->name, str)==0)
			return;
	return;
}
table_element *find_bottom(table_element *aux){
		table_element *aux2=aux;
		while(aux2){
			if(aux2->next==NULL)
				return aux2;
			else 
				aux2=aux2->next;
		}
}
int n_params(table_element *aux){
	int i=0;
	if(aux->next!=NULL)
		aux=aux->next;
	else
		return i;
	while(strcmp(aux->scope, "var")==0||strcmp(aux->scope, "params")==0){
		if(strcmp(aux->scope, "params")==0)
			i++;
		if(aux->next==NULL)
			break;
		aux=aux->next;	
	}		
	return i;

}


void show_table(){

	table_element *aux, *aux2, *findvp;
	printf("\n");
	aux = find_bottom(symtab);
	aux2 = find_bottom(symtab);
	while(aux){ 
		//printf("%s, %s, %s\n", aux->name, aux->type, aux->scope);
		if(aux->next==NULL)
			printf("===== Global Symbol Table =====\n", aux->name, aux->type, aux->scope);
		if(strcmp(aux->scope, "gvar")==0){
			*(aux->type) = tolower(*(aux->type));
			printf("%s\t\t%s\n", aux->name, aux->type);		
		}
		if(strcmp(aux->scope,"Func")==0){
			printf("%s\t(", aux->name);
			if(aux->next!=NULL){
				table_element *findp = aux->next;
				int c = n_params(aux);
				int sizepam = c;
				while(sizepam!=0){
				
					if(strcmp(findp->scope, "params")==0){
						*(findp->type) = tolower(*(findp->type));
						if(sizepam==c)
							printf("%s", findp->type);						
						else					
							printf(" %s",findp->type);
					sizepam--;
					}

					if(findp->next==NULL)
						break;
					findp=findp->next;
				}
			}
			printf(")");
			if(strcmp(aux->prev->type, "retfunc")==0){
				*(aux->prev->name) = tolower(*(aux->prev->name));
				printf("\t%s\n", aux->prev->name);
			}
			else
				printf("\tnone\n");
				
			
		}	
		if(aux->prev==NULL){
			break;
		}
		aux=aux->prev;
	}
	while(aux2){
		if(strcmp(aux2->scope,"Func")==0){
			printf("===== Function %s(",aux2->name);
			table_element *findpa = aux2;
			int n = n_params(aux2);
			int a = n;
			while(a!=0){
				
				if(strcmp(findpa->scope, "params")==0){
					*(findpa->type) = tolower(*(findpa->type));
					if(a==n)
						printf("%s", findpa->type);						
					else					
						printf(" %s",findpa->type);
					a--;
				}

				if(findpa->next==NULL)
					break;
				findpa=findpa->next;
			}
			printf(") Symbol Table =====\n");
			if(strcmp(aux2->prev->type, "retfunc")==0){
				*(aux2->prev->name) = tolower(*(aux2->prev->name));
				printf("return\t%s\n", aux2->prev->name);
			}	
			
			else{				
				printf("return\tnone\n");
			}
			if(aux2->next!=NULL){
				table_element *achaparam = aux2->next;
				while(strcmp(achaparam->scope, "Func")!=0){							
					if(strcmp(achaparam->scope, "params")==0){
						*(achaparam->type) = tolower(*(achaparam->type));
						printf("%s\t%s\tparam\n", achaparam->name, achaparam->type);			
					}
					if(achaparam->next==NULL)
						break;
					achaparam=achaparam->next;
				}
			}			
			findvp = aux2;
			while(findvp){	
				if(strcmp(findvp->scope, "var")==0){
					*(findvp->type) = tolower(*(findvp->type));
					printf("%s\t\t%s\n", findvp->name, findvp->type);			
				}
				if((findvp->next==NULL)||(strcmp(findvp->next->type, "Func")==0))
					break;
				findvp=findvp->next;
			}
		}
		if(aux2->prev==NULL)
			break;
		aux2=aux2->prev;
	}
}

