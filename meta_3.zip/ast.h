
typedef struct tnode *node;
typedef struct tnode{
    node child;
    node brother;
    char* token;			// Name of TreeToken
    char* value;			// Value of TreeToken ex. ID(main) Token(value)
    int printable;			// visibility while printing tree

   	int n;					//Debugging purposes
   	int n_childs;			//    "		    " 		

}t_node;

node new_node(char* token, char* value, int printable, int n);
void insert_child(node father, node child);
void append_brother(node init_node, node new_brother);
void preorder_print(node root, int dep);
void insert_type_declaration(node typespec, node fst_decl);
node check_statlist(node tnode, int n);