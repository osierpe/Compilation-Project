#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H


typedef struct _t1{
	char *name;
	char *type;
	char *scope;
	struct _t1 *next;
	struct _t1 *prev;
} table_element;

void insert_el(char *str, char *type, char *scope);
void search_el(char *str);
void show_table();
#endif
