#include "ast.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

node new_node(char* token, char* value, int printable,int n){
	
	node new_node = (node)malloc(sizeof(t_node));
	
	new_node->child = NULL;
	new_node->brother = NULL;
	new_node->token = (char*)strdup(token);
	new_node->value = (char*)strdup(value);
	new_node->printable = printable;

	new_node->n = n+1;
	new_node->n_childs = 0;	

	return new_node; 
}

void insert_child(node father, node child){
	father->child = child;
	father->n_childs++;
}

void append_brother(node init_node, node new_brother){
	node curr = init_node;

	while(curr->brother != NULL){
		curr = curr->brother;
	}

	curr->brother = new_brother;
}

void insert_type_declaration(node typespec, node fst_decl){
	node tmp = fst_decl;
	tmp->child->token = strdup(typespec->token);
	tmp = tmp->brother;
	while(tmp!=NULL){
		tmp->child->token = strdup(typespec->token);
		tmp = tmp->brother;
	}
	
}

void preorder_print(node root, int dep){
	int tmp = dep;

	if(root == NULL){
		return;
	}

	while(tmp>0){
		printf("..");
		tmp--;
	}

	if(root->printable){
		printf("%s",root->token);
		if(strcmp(root->value,"NULL")!=0){
			printf("(%s)\n",root->value);
		}else{
			printf("\n");
		}
	}

	preorder_print(root->child,dep+1);
	preorder_print(root->brother,dep);
}

node check_statlist(node tnode, int n){
	int counter = 0;
	node tmp = tnode;

	while(tmp!=NULL){
		tmp = tmp->brother;
		counter++;
	}

	if(counter == 0){
		// StAux is empty, create special node Null
		node tnull = new_node("Null","NULL",1,n);
		return tnull;
												//VERIFICAR ESTA CENA, NOT SURE 	
	}else if(counter >= 2){
		// StAux is a StatList
		node temp = new_node("StatList","NULL",1,n);
		insert_child(temp,tnode);
		return temp;
	}else{
		return tnode;
	}
}
